function [centre] = centre_gravite(A,B,C)
%calcul du centre de gravité du triangle ABC
%Méthode de la moyenne v1.0

centre = (A + B + C)/ 3;

end