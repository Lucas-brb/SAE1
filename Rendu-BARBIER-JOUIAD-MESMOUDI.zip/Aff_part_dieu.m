load('Sommets Part Dieu 2020.mat')
load("Triangles Part Dieu 2020.mat")
Aff_verification(Sommets,Triangles,[0 0 0])